# TechInnovate Solutions - WEDE5020POF Part 2

## Project Overview
TechInnovate Solutions is a responsive technology company website demonstrating advanced CSS styling and responsive design principles for the WEDE5020POF assignment.

## Technology Stack
- **Frontend:** HTML5, CSS3, JavaScript (ES6+)
- **Layout:** CSS Grid & Flexbox
- **Styling:** CSS Custom Properties (Variables)
- **Responsive:** Mobile-first design
- **Icons:** Emoji-based (for demonstration)

## Features Implemented

### 🎨 CSS Styling
- External stylesheet with modular architecture
- CSS custom properties for consistent theming
- Typography scale using relative units (rem)
- Gradient backgrounds and modern color scheme
- Card-based design system with hover effects

### 📱 Responsive Design
- Mobile-first approach with progressive enhancement
- Breakpoints: 768px (tablet), 480px (mobile)
- Flexible grid systems using CSS Grid
- Responsive navigation with hamburger menu
- Optimized touch targets for mobile devices

### ⚡ Technical Features
- Semantic HTML5 structure
- Accessible navigation and forms
- CSS transitions and animations
- Print styles for documentation
- Reduced motion support for accessibility

## File Structure